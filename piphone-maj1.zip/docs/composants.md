# Composants étape 0 (À VALIDER avant achat)

Principe : tout en modules et cartes de dev, aucune soudure fine, pas de batterie (alimentation secteur USB-C).

| Fonction | Choix étape 0 | Remarque |
|---|---|---|
| Carte de dev | Raspberry Pi 4 (4 ou 8 Go) | Support Linux très large ; Pi 5 possible mais plus gourmand |
| Alimentation + microSD | Alim USB-C officielle + carte microSD 32 Go minimum | |
| Écran tactile | Écran tactile DSI officiel 7" ou écran 5-6" HDMI + USB tactile | La taille finale (~6") se décide à l'étape 1 |
| Modem 4G | Quectel EG25-G (variante Europe) sur carte mini-PCIe + adaptateur USB, ou HAT 4G USB équivalent | Vérifier la VoLTE avec l'opérateur ; 5G plus tard |
| SIM | Nano SIM avec voix et data | |
| Antennes | 2 antennes LTE, 1 antenne LoRa 868 MHz | Ne jamais émettre sans antenne branchée |
| Audio d'appel | Carte son USB avec micro + haut-parleur ou casque | Nécessaire pour entendre et parler pendant un appel |
| LoRa | Module ou HAT SX1262 868 MHz (SPI) | Prendre 2 modules pour tester l'échange |
| NFC | Module PN532 (simple, bien supporté) | PN7160 envisagé à l'étape 1 |
| Batterie | Aucune à l'étape 0 | Ajoutée à l'étape 1 avec circuit de charge et protection |
