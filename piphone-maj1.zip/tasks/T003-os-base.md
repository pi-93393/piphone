# T003 : installer l'OS de base sur la carte de dev
- Agent : opencode (Pierre exécute les commandes)
- Statut : à faire (après réception du matériel)
- Fichiers : `software/scripts/`, `docs/install.md` (création)
- Objectif : Raspberry Pi OS (ou Debian arm64) + Phosh installé par les paquets, démarrage sur l'interface mobile avec écran tactile. ModemManager installé. Documenter les étapes réelles et un script d'installation.
- Note : on ne part pas de postmarketOS à l'étape 0, son support carte de dev est incertain. Migration possible à l'étape 1.
- Réussite : démarrage jusqu'à l'interface Phosh, tactile utilisable.
