# T001 : commander le matériel étape 0
- Agent : pierre
- Statut : à faire
- Voir `docs/composants.md`. Vérifier chaque référence exacte (variante Europe du modem, fréquence 868 MHz du LoRa) avant achat.
