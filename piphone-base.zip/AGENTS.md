# Règles pour les agents (Codex, OpenCode, Claude)

Projet : smartphone Linux maison. Lis ce fichier, puis UNIQUEMENT ta tâche dans `tasks/`.

## Économie de tokens
- Ne parcours pas tout le dépôt. Ouvre seulement les fichiers listés dans ta tâche.
- Ne réécris pas un fichier entier pour une petite modification.
- Réponses courtes. Pas d'explications si le code est clair.
- Si la tâche est ambiguë, pose UNE question, ne devine pas.

## Conventions
- Base logicielle : postmarketOS + Phosh (modifiable plus tard).
- Matériel : KiCad 8, BOM en CSV dans `hardware/bom/`.
- Scripts en bash ou Python 3, commentaires en français.
- Un commit par tâche, message : `T00X: résumé court`.
- Quand c'est fini : passe le statut de la tâche à `fait` et note en 3 lignes max ce qui a été testé.

## Répartition
- codex : tâches courtes (scripts, CSV, petites corrections)
- opencode : gros développements (pilotes, device tree, interface, applis)
- claude : architecture, choix de composants, relecture
- pierre : commandes, soudure, tests physiques
