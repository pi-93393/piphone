# Tâches
Une tâche = un fichier `T00X-nom.md`. Modèle :

```
# T00X : titre
- Agent : codex | opencode | claude | pierre
- Statut : à faire | en cours | fait
- Fichiers : ceux à lire / créer
- Objectif :
- Réussite :
```
