# T003 : installer l'OS de base sur la carte de dev
- Agent : opencode (Pierre exécute les commandes)
- Statut : à faire (après réception de la carte)
- Fichiers : `software/scripts/`, `docs/install.md` (création)
- Objectif : postmarketOS + Phosh démarre avec écran tactile. Documenter les étapes réelles et le script d'installation.
- Réussite : démarrage jusqu'à l'interface, tactile utilisable.
