# T006 : NFC
- Agent : codex
- Statut : à faire (après T003)
- Fichiers : `software/nfc/` (création)
- Objectif : petit script qui lit l'UID d'un badge NFC avec le lecteur retenu.
- Réussite : UID affiché dans le terminal.
