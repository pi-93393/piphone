# T001 : commander le matériel étape 0
- Agent : pierre
- Statut : à faire
- Voir `docs/composants.md`. Valider chaque référence avec Claude avant achat.
