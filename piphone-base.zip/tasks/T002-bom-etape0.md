# T002 : BOM étape 0 en CSV
- Agent : codex
- Statut : à faire
- Fichiers : `docs/composants.md` (lecture), `hardware/bom/etape0.csv` (création)
- Objectif : CSV avec colonnes fonction, référence, quantité, fournisseur, lien. Laisser vide ce qui n'est pas encore validé.
- Réussite : le CSV s'ouvre dans un tableur sans erreur.
