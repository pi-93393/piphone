# T005 : LoRa SX1262
- Agent : opencode
- Statut : à faire (après T003)
- Fichiers : `software/lora/` (création)
- Objectif : piloter le module en SPI, outil en ligne de commande pour envoyer et recevoir un message à 868 MHz.
- Réussite : message échangé entre le module et un second module LoRa.
