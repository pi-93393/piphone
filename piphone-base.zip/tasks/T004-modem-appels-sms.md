# T004 : modem, appels et SMS
- Agent : opencode
- Statut : à faire (après T003)
- Fichiers : `software/scripts/modem-check.sh` (création), `docs/modem.md` (création)
- Objectif : détecter le modem via ModemManager, envoyer/recevoir un SMS, passer un appel. Noter si la VoLTE fonctionne avec la SIM de Pierre.
- Réussite : SMS et appel testés, résultats notés dans `docs/modem.md`.
