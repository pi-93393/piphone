# PiPhone

Smartphone maison sous Linux : carte électronique conçue sur mesure, firmware basé sur une distribution mobile open source, interface et applis dédiées.

**Statut : étape 0 (prototype sur carte de dev).** Voir `docs/roadmap.md`.

- `docs/` : cahier des charges, roadmap, composants
- `hardware/` : KiCad, BOM
- `software/` : build, device tree, scripts, interface, applis
- `tasks/` : une tâche = un fichier, assignée à un agent
