# Logiciel
- `scripts/` : scripts d'installation, de test et de flash
- `lora/`, `nfc/` : outils de test des modules (créés par les tâches)
Base : postmarketOS + Phosh.
