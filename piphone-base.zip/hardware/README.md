# Matériel
- `bom/` : listes de composants en CSV
- Projet KiCad à créer ici à l'étape 1 (`kicad/`)
Règle : composants courants et en stock chez JLCPCB quand c'est possible, pour l'assemblage.
