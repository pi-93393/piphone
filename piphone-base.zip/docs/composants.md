# Composants étape 0 (candidats, À VALIDER avant achat)

| Fonction | Candidat | Remarque |
|---|---|---|
| Carte de dev | Raspberry Pi 4 (si déjà dispo) ou carte RK3566 | Le Pi 4 a un support Linux large ; pour une carte Rockchip, vérifier le support postmarketOS avant d'acheter |
| Modem 4G | Quectel EG25-G | Géré par ModemManager ; vérifier VoLTE avec l'opérateur |
| LoRa | Module SX1262 868 MHz (SPI) | Antenne 868 MHz obligatoire |
| NFC | NXP PN7160 ou ST25R | Vérifier le pilote Linux |
| Écran tactile | À choisir selon la taille retenue | Interface DSI ou HDMI + USB tactile |
| Batterie | Li-Po + carte de charge/protection | Taille selon le format du boîtier |
