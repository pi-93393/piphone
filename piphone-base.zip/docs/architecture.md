# Architecture (v0)

```
Écran tactile ─┐
Batterie/charge ┤
Modem 4G/5G ────┼── SoC / SoM (Linux) ── Wi-Fi/Bluetooth
LoRa SX1262 ────┤
NFC ────────────┘
```

- Interfaces prévues : modem en USB ou PCIe/M.2, LoRa en SPI, NFC en I2C ou SPI, écran en DSI ou MIPI, tactile en I2C.
- Logiciel : postmarketOS + Phosh, puis surcouche maison. Modem géré par ModemManager.
- Étape 0 : tout sur carte de dev. Étape 1 : carte porteuse KiCad autour d'un SoM.
