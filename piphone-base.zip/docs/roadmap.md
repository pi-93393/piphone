# Roadmap

## Étape 0 : prototype sans PCB maison
Carte de dev + modem 4G + écran tactile + batterie. Valider le logiciel : Linux mobile, appels, SMS, tactile, LoRa, NFC.

## Étape 1 : carte porteuse maison
PCB KiCad autour d'un SoM : modem, Wi-Fi/BT, LoRa, NFC, gestion batterie, écran. Boîtier 3D.

## Étape 2 : version puissante
SoC plus costaud (émulation, 3D), thermique, autonomie, surcouche d'interface aboutie.
