# Cahier des charges v0

## Objectif du prototype (étape 0-1)
Téléphone fonctionnel : écran tactile, appels, SMS, Linux mobile open source modifié, quelques applis dédiées.

## Objectifs à terme
- Connectivité maximale : 4G, 5G, Wi-Fi, Bluetooth, NFC, LoRa intégré par défaut (868 MHz, Europe)
- Performances pour émulation et jeux 3D
- Interface et applis propres au projet

## Contraintes
- PCB commandés chez JLCPCB (assemblage JLCPCB possible), composants achetés tels quels
- Pas de SoC maison : module (SoM) ou carte de dev au début
- Boîtier imprimé en 3D
- Pas de délai imposé, budget flexible mais à surveiller

## Points à trancher
- Taille et format de l'écran (à décider par Pierre)
- Choix du SoC pour l'étape 1
- VoLTE : la 2G/3G est en cours d'arrêt en France, vérifier le support modem + opérateur
- Certification CE si le produit sort du cadre perso
